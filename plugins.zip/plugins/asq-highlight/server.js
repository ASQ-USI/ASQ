/** @module server.js
    @description serverside handling of asq-highlight questions   
*/